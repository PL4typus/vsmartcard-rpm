.. meta::
    :http-equiv=refresh: 0;URL='https://github.com/frankmorgner/OpenSC'

######################
nPA Smart Card Library
######################

Access the German electronic identity card (neuer Personalausweis/nPA).

The functionality of nPA Smart Card Library has been integrated into
OpenSC. Developement and Support will continue at our new home
https://github.com/frankmorgner/OpenSC.
